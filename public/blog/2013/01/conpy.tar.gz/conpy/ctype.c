#include <stdio.h>


unsigned long long Kaijo(int x)
{
	int i;
	unsigned long long tmp, n=1;

	for(i=2; i<=x; i++)
	{
		tmp = n * i;
		if(tmp < n)
			return 0;
		n = tmp;
	}

	return n;
}

void KaijoLoop(int x, int loop)
{
	int i;

	for(i=0; i<loop; i++)
		Kaijo(x);
}

int Adler32(const unsigned char *data, size_t len)
{
	unsigned int a=1, b=0;
	size_t n;

	for(n=0; n<len; n++)
	{
		a = (a + data[n]) % 65521;
		b = (b + a) % 65521;
	}
	return (b << 16) + a;
}

void Adler32Loop(const unsigned char *data, size_t len, int loop)
{
	int i;

	for(i=0; i<loop; i++)
		Adler32(data, len);
}
