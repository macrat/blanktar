#include <Python.h>


unsigned long long Kaijo(int x)
{
	int i;
	unsigned long long tmp, n=1;

	for(i=2; i<=x; i++)
	{
		tmp = n * i;
		if(tmp < n)
			return 0;
		n = tmp;
	}

	return n;
}

static PyObject *PyKaijo(PyObject *self, PyObject *args)
{
	int x;
	unsigned long long n;

	if(!PyArg_ParseTuple(args, "i", &x))
		return NULL;

	n = Kaijo(x);
	if(n == 0)
	{
		PyErr_SetString(PyExc_ValueError, "overflow!");
		return NULL;
	}

	return Py_BuildValue("K", n);
}

static PyObject *PyKaijoLoop(PyObject *self, PyObject *args)
{
	int i, loop, x;
	unsigned long long n;

	if(!PyArg_ParseTuple(args, "ii", &x, &loop))
		return NULL;

	for(i=0; i<loop; i++)
	{
		n = Kaijo(x);
		if(n == 0)
		{
			PyErr_SetString(PyExc_ValueError, "overflow!");
			return NULL;
		}
	}

	Py_RETURN_NONE;
}

unsigned int Adler32(const unsigned char *data, size_t len)
{
	unsigned int a=1, b=0;
	size_t n;

	for(n=0; n<len; n++)
	{
		a = (a + data[n]) % 65521;
		b = (b + a) % 65521;
	}
	return (b << 16) + a;
}

static PyObject *PyAdler32(PyObject *self, PyObject *args)
{
	unsigned char *data;
	size_t size;
	unsigned int adler;

	if(!PyArg_ParseTuple(args, "s#", &data, &size))
		return NULL;

	adler = Adler32(data, size);

	return Py_BuildValue("i", adler);
}

static PyObject *PyAdler32Loop(PyObject *self, PyObject *args)
{
	int i, loop;
	unsigned char *data;
	size_t size;

	if(!PyArg_ParseTuple(args, "s#i", &data, &size, &loop))
		return NULL;

	for(i=0; i<loop; i++)
		Adler32(data, size);

	Py_RETURN_NONE;
}

static PyMethodDef methods[] = {
	{"Kaijo", PyKaijo, METH_VARARGS, "kaijou\n"},
	{"KaijoLoop", PyKaijoLoop, METH_VARARGS, "loop kaijou\n"},
	{"Adler32", PyAdler32, METH_VARARGS, "adler32\n"},
	{"Adler32Loop", PyAdler32Loop, METH_VARARGS, "loop adler32\n"},
	{NULL, NULL, 0, NULL}
};

void initpyapi()
{
	Py_InitModule("pyapi", methods);
}
