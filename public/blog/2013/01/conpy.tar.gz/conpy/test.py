#!/usr/bin/python2
#coding:utf-8

import time

import pyapi
import ctypes


def Kaijo(x):
	n = 1
	for i in range(2, x+1):
		n *= i
	return n


def Adler32(data):
	a = 1
	b = 0
	for n in data:
		a = (a + ord(n)) % 65521;
		b = (b + a) % 65521;

	return (b << 16)+ a;


def Bench(f, c=10):
	t = 0
	for i in range(c):
		stime = time.time()
		f()
		etime = time.time()
		t += etime-stime
	return t / c


if __name__ == '__main__':
	ctype = ctypes.CDLL('./ctype.so')

	print u'----階乗計算-----'
	print u'20の階乗を一万回計算してみる'
	print u'python:', Bench(lambda :[Kaijo(20) for x in xrange(10000)]), '秒くらい'
	print u'pythonAPI:', Bench(lambda :pyapi.KaijoLoop(20, 10000)), '秒くらい'
	print u'ctypes:', Bench(lambda :ctype.KaijoLoop(20, 10000)), '秒くらい'
	print
	print u'-----Adler32-----'
	print u'アルファベットのAdler32を一万回計算してみる'
	s = 'abcdefghijklmnopqrstuvwxyz'
	print u'python:', Bench(lambda :[Adler32(s) for x in xrange(10000)]), '秒くらい'
	print u'pythonAPI:', Bench(lambda :pyapi.Adler32Loop(s, 10000)), '秒くらい'
	print u'ctypes:', Bench(lambda :ctype.Adler32Loop(s, len(s), 10000)), '秒くらい'
